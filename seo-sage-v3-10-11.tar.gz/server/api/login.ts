export default defineEventHandler((event) => {
    return {
      hello: 'world'
    }
  })