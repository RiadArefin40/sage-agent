<template>
  <svg
      width="48"
      height="48"
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class="text-[#42526E] fill-current group-hover:text-[#36B37E]"
  >
    <g clip-path="url(#clip0_2611_3781)">
      <path
          d="M46.9255 21H26.9903V1C26.9903 0.4475 26.5442 0 25.9935 0H22.0064C21.4557 0 21.0097 0.4475 21.0097 1V21H1.0744C0.523688 21 0.0776367 21.4475 0.0776367 22V26C0.0776367 26.5525 0.523688 27 1.0744 27H21.0097V47C21.0097 47.5525 21.4557 48 22.0064 48H25.9935C26.5442 48 26.9903 47.5525 26.9903 47V27H46.9255C47.4762 27 47.9223 26.5525 47.9223 26V22C47.9223 21.4475 47.4762 21 46.9255 21Z"
      />
    </g>
    <defs>
      <clipPath id="clip0_2611_3781">
        <rect
            width="48"
            height="48"
            fill="white"
        />
      </clipPath>
    </defs>
  </svg>
</template>

<script>
export default {
name: "plus"
}
</script>

<style scoped>

</style>