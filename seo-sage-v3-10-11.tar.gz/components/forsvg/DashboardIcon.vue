<template>
    <svg
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
    >
        <path
            d="M5 2V4H15V3C15 2.44687 14.5531 2 14 2H5ZM4 2H2C1.44687 2 1 2.44687 1 3V4H4V2ZM1 5V13C1 13.5531 1.44687 14 2 14H14C14.5531 14 15 13.5531 15 13V5H4.5H1ZM0 3C0 1.89688 0.896875 1 2 1H14C15.1031 1 16 1.89688 16 3V13C16 14.1031 15.1031 15 14 15H2C0.896875 15 0 14.1031 0 13V3Z"
            fill="#172B4D"
        />
    </svg>
</template>

<script>
export default {
    name: "Dashboard",
};
</script>
