<template>
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="10" cy="10" r="10" fill="#BBF7D0" />
        <path opacity="0.4"
            d="M6.42857 5C5.64063 5 5 5.64063 5 6.42857V13.5714C5 14.3594 5.64063 15 6.42857 15H11.4286V12.1429C11.4286 11.7478 11.7478 11.4286 12.1429 11.4286H15V6.42857C15 5.64063 14.3594 5 13.5714 5H6.42857Z"
            fill="black" />
        <path
            d="M11.4286 12.1429V15H11.5513C11.9308 15 12.2946 14.8505 12.5625 14.5826L14.5826 12.5625C14.8504 12.2947 15 11.9308 15 11.5514V11.4286H12.1428C11.7478 11.4286 11.4286 11.7478 11.4286 12.1429Z"
            fill="black" />
    </svg>
</template>

<script>
export default {
    name: "Reasoning",
};
</script>

<style scoped></style>
