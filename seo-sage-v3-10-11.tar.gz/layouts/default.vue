<script setup lang="ts"></script>

<template>
  <div>
    <!-- <AgencyTopHeader /> -->
    <!-- <AgencyPanelSidebar />
    <AgencyMiniSidebar></AgencyMiniSidebar> -->
    <slot />
  </div>
</template>

<style scoped></style>
